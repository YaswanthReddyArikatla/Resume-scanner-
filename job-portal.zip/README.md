# Job Portal - Full Stack App

A full-stack web app for uploading resumes, scanning skills, and matching jobs.

## Tech Stack
- Frontend: HTML, CSS, JS
- Backend: Node.js, Express
- Database: MongoDB (Mongoose)
- Auth: JWT, bcrypt
- File Handling: Multer
- Resume Parsing: pdf-parse, mammoth
- Deployment: Docker, Render, GH Actions

## Running Locally

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

Open http://localhost:5000

## Docker Compose

```bash
docker-compose up --build
```

## CI/CD

This repo includes a GitHub Actions workflow `.github/workflows/build-and-deploy.yml`
that builds a Docker image, publishes to GHCR, and triggers a Render deploy.

Set GitHub Secrets:
- RENDER_API_KEY
- RENDER_SERVICE_ID
