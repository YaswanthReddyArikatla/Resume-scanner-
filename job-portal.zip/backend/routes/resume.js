const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { extractTextFromFile } = require('../utils/extractText');
const Application = require('../models/Application');
const auth = require('../middleware/auth');

const router = express.Router();
const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

const jobs = [
  { title: "Frontend Developer", keywords: ["javascript","react","html","css"] },
  { title: "Data Scientist", keywords: ["python","tensorflow","pandas","nlp"] },
  { title: "Backend Developer", keywords: ["node.js","express","mongodb","api"] }
];

function extractSkills(text) {
  const skills = ["javascript","react","node.js","mongodb","css","html","tensorflow","nlp","python","express","api","pandas"];
  text = text.toLowerCase();
  return skills.filter(skill => text.includes(skill));
}

router.post('/upload', auth, upload.single('resume'), async (req, res) => {
  const text = await extractTextFromFile(req.file.path, req.file.mimetype);
  const skills = extractSkills(text);
  const matched = jobs.filter(j => j.keywords.some(k => skills.includes(k)));

  const saved = [];
  for (const job of matched) {
    const app = new Application({
      user: req.user.id,
      jobTitle: job.title,
      resumeFile: req.file.filename,
      skills
    });
    await app.save();
    saved.push(job.title);
  }

  res.json({ matched: matched.map(m => m.title), skills, saved });
});

router.get('/applications', auth, async (req, res) => {
  const apps = await Application.find({ user: req.user.id }).sort({ createdAt: -1 });
  res.json({ applications: apps });
});

module.exports = router;
