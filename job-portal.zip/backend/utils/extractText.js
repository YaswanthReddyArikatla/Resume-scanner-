const fs = require('fs/promises');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');

async function extractTextFromFile(path, mimetype) {
  if (mimetype === 'application/pdf' || path.endsWith('.pdf')) {
    const data = await fs.readFile(path);
    const res = await pdfParse(data);
    return res.text;
  }
  if (mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || path.endsWith('.docx')) {
    const result = await mammoth.extractRawText({ path });
    return result.value;
  }
  try {
    return await fs.readFile(path, 'utf8');
  } catch {
    return '';
  }
}

module.exports = { extractTextFromFile };
